# Contributing to SAP Skills Power

Thank you for your interest in contributing to the SAP Skills Power for Kiro! This document provides guidelines and instructions for contributing.

## 🤝 How to Contribute

### Reporting Issues

If you find a bug or have a suggestion:

1. Check if the issue already exists in [GitHub Issues](https://github.com/mfigueir/sap-skills-power/issues)
2. If not, create a new issue with:
   - Clear title and description
   - Steps to reproduce (for bugs)
   - Expected vs actual behavior
   - Your environment (Kiro version, OS, SAP products)
   - Relevant code snippets or screenshots

### Suggesting Enhancements

We welcome suggestions for new skills or improvements:

1. Open a GitHub Discussion or Issue
2. Describe the enhancement clearly
3. Explain the use case and benefits
4. Provide examples if possible

### Pull Requests

1. **Fork the repository**
   ```bash
   git clone https://github.com/mfigueir/sap-skills-power.git
   cd sap-skills-power
   ```

2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make your changes**
   - Follow the coding standards below
   - Update documentation as needed
   - Test with real SAP projects

4. **Commit your changes**
   ```bash
   git add .
   git commit -m "Add: Brief description of your changes"
   ```

5. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

6. **Open a Pull Request**
   - Provide a clear description
   - Reference any related issues
   - Include screenshots if applicable

## 📝 Coding Standards

### Steering Files

When adding or updating steering files:

- Use clear, concise language
- Include practical code examples
- Follow SAP best practices
- Structure content with proper headings
- Add links to official SAP documentation

### Documentation

- Keep README.md up to date
- Document new skills in POWER.md
- Update version history
- Include usage examples

### File Structure

```
sap-skills/
├── POWER.md                    # Power configuration
├── README.md                   # Main documentation
├── LICENSE                     # GPL v3.0
├── CONTRIBUTING.md             # This file
└── steering/
    ├── getting-started.md      # Quick start
    ├── best-practices.md       # Standards
    ├── cap-development.md      # CAP patterns
    ├── ui5-development.md      # UI5 guidance
    └── [new-guide].md          # New guides
```

## 🎯 Adding New Skills

To add a new SAP skill:

1. **Update POWER.md**
   - Add skill to appropriate category
   - Include description and use cases
   - Update skill count

2. **Create or Update Steering Guide**
   - Add detailed guidance for the skill
   - Include code examples
   - Reference official documentation

3. **Update README.md**
   - Add to skill list
   - Include usage example
   - Update feature count

4. **Test Thoroughly**
   - Test with real SAP projects
   - Verify automatic activation
   - Check integration with MCP servers

## ✅ Quality Checklist

Before submitting a PR, ensure:

- [ ] Code follows SAP best practices
- [ ] Documentation is clear and complete
- [ ] Examples are tested and working
- [ ] No sensitive information included
- [ ] Commit messages are descriptive
- [ ] Changes are focused and atomic
- [ ] All files use consistent formatting
- [ ] Links to external resources work

## 🧪 Testing

Test your changes with:

1. **CAP Projects**
   - Create a new CAP project
   - Test CDS model guidance
   - Verify service implementation patterns

2. **UI5 Projects**
   - Create a Fiori app
   - Test UI5 control recommendations
   - Verify responsive design guidance

3. **ABAP Projects**
   - Test ABAP code analysis
   - Verify CDS view creation
   - Check Clean ABAP recommendations

4. **BTP Deployments**
   - Test deployment guidance
   - Verify service configuration
   - Check security setup

## 📚 Resources

### SAP Documentation
- [SAP CAP](https://cap.cloud.sap/docs/)
- [SAPUI5](https://ui5.sap.com/)
- [SAP BTP](https://help.sap.com/docs/btp)
- [Clean ABAP](https://github.com/SAP/styleguides)

### Kiro Documentation
- [Kiro Powers](https://kiro.dev/docs/powers)
- [Kiro Steering](https://kiro.dev/docs/steering)

## 🏆 Recognition

Contributors will be:
- Listed in the README.md
- Credited in release notes
- Mentioned in the SAP Community

## 📞 Questions?

- Open a [GitHub Discussion](https://github.com/mfigueir/sap-skills-power/discussions)
- Ask in [SAP Community](https://community.sap.com/)
- Check existing [Issues](https://github.com/mfigueir/sap-skills-power/issues)

## 📄 License

By contributing, you agree that your contributions will be licensed under the GNU General Public License v3.0.

---

Thank you for contributing to the SAP Skills Power! 🎉
