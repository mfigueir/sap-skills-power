# Changelog

All notable changes to the SAP Skills Power will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-01-14

### Added
- Initial release of SAP Skills Power for Kiro
- 35+ specialized SAP development skills
- 4 comprehensive steering guides:
  - Getting Started guide
  - Best Practices guide
  - CAP Development guide
  - UI5 Development guide
- Automatic context activation for SAP file types
- Integration with SAP MCP servers
- Support for SAP BTP Platform (14 skills)
- Support for UI Development (4 skills)
- Support for Data & Analytics (5 skills)
- Support for Core Technologies (6 skills)
- Support for Tooling & Development (4 skills)

### Skills Included

#### Tooling & Development
- skill-review
- sap-api-style
- sap-hana-cli
- sapui5-linter

#### SAP BTP Platform
- sap-btp-best-practices
- sap-btp-build-work-zone-advanced
- sap-btp-business-application-studio
- sap-btp-cias
- sap-btp-cloud-logging
- sap-btp-cloud-platform
- sap-btp-cloud-transport-management
- sap-btp-connectivity
- sap-btp-developer-guide
- sap-btp-integration-suite
- sap-btp-intelligent-situation-automation
- sap-btp-job-scheduling
- sap-btp-master-data-integration
- sap-btp-service-manager

#### UI Development
- sap-fiori-tools
- sapui5
- sapui5-cli
- sapui5-linter

#### Data & Analytics
- sap-datasphere
- sap-hana-cloud-data-intelligence
- sap-sac-custom-widget
- sap-sac-planning
- sap-sac-scripting

#### Core Technologies
- sap-abap
- sap-abap-cds
- sap-ai-core
- sap-cap-capire
- sap-cloud-sdk-ai
- sap-hana-ml
- sap-sqlscript

### Documentation
- Comprehensive README.md
- LICENSE (GPL v3.0)
- CONTRIBUTING.md
- CHANGELOG.md
- .gitignore

### Based On
- SAP Skills for Claude Code v2.1.0 (2025-12-27)
- Repository: https://github.com/secondsky/sap-skills

## [Unreleased]

### Planned
- Additional ABAP modernization patterns
- Expanded BTP service integration examples
- SAP Build Apps guidance
- SAP Integration Suite patterns
- SAP Analytics Cloud advanced examples
- Video tutorials
- Interactive examples
- Community-contributed skills

---

## Version History Format

### [Version] - YYYY-MM-DD

#### Added
- New features and capabilities

#### Changed
- Changes to existing functionality

#### Deprecated
- Features that will be removed in future versions

#### Removed
- Features that have been removed

#### Fixed
- Bug fixes

#### Security
- Security-related changes

---

For more details, see the [GitHub Releases](https://github.com/mfigueir/sap-skills-power/releases) page.
