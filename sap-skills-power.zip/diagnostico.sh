#!/bin/bash

echo "🔍 Diagnóstico do Problema de Push"
echo "===================================="
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "POWER.md" ]; then
    echo "❌ Execute este script dentro da pasta sap-skills/"
    exit 1
fi

echo "1️⃣ Verificando repositório Git local..."
if [ -d ".git" ]; then
    echo "✅ Repositório Git existe"
else
    echo "❌ Repositório Git não existe"
    exit 1
fi
echo ""

echo "2️⃣ Verificando branch atual..."
current_branch=$(git branch --show-current 2>/dev/null || echo "nenhuma")
echo "Branch atual: $current_branch"
echo ""

echo "3️⃣ Verificando commits..."
commit_count=$(git rev-list --count HEAD 2>/dev/null || echo "0")
echo "Número de commits: $commit_count"
if [ "$commit_count" = "0" ]; then
    echo "❌ Nenhum commit encontrado!"
else
    echo "✅ Commits existem"
    echo ""
    echo "Último commit:"
    git log -1 --oneline
fi
echo ""

echo "4️⃣ Verificando remote..."
if git remote -v | grep -q "origin"; then
    echo "✅ Remote 'origin' configurado:"
    git remote -v
else
    echo "❌ Remote 'origin' não configurado"
fi
echo ""

echo "5️⃣ Verificando conectividade com GitHub..."
if curl -s -o /dev/null -w "%{http_code}" https://github.com/mfigueir/sap-skills-power 2>/dev/null | grep -q "200\|404"; then
    echo "✅ Conectividade com GitHub OK"
else
    echo "⚠️  Problema de conectividade com GitHub"
fi
echo ""

echo "6️⃣ Verificando se o repositório existe no GitHub..."
status_code=$(curl -s -o /dev/null -w "%{http_code}" https://github.com/mfigueir/sap-skills-power 2>/dev/null)
if [ "$status_code" = "200" ]; then
    echo "✅ Repositório existe no GitHub"
    echo "⚠️  ATENÇÃO: Repositório já tem conteúdo!"
    echo ""
    echo "Isso pode causar conflito. Soluções:"
    echo "a) Fazer pull primeiro: git pull origin main --allow-unrelated-histories"
    echo "b) Forçar push: git push -u origin main --force"
elif [ "$status_code" = "404" ]; then
    echo "❌ Repositório NÃO existe no GitHub"
    echo ""
    echo "SOLUÇÃO: Crie o repositório primeiro em:"
    echo "https://github.com/new"
    echo "Nome: sap-skills-power"
else
    echo "⚠️  Status desconhecido: $status_code"
fi
echo ""

echo "7️⃣ Verificando arquivos staged..."
staged_files=$(git diff --cached --name-only | wc -l)
echo "Arquivos staged: $staged_files"
echo ""

echo "8️⃣ Verificando status do Git..."
git status --short
echo ""

echo "=================================="
echo "📋 RESUMO DO DIAGNÓSTICO"
echo "=================================="
echo ""

# Determinar o problema
if [ "$commit_count" = "0" ]; then
    echo "❌ PROBLEMA: Nenhum commit encontrado"
    echo ""
    echo "SOLUÇÃO:"
    echo "git add ."
    echo "git commit -m 'Initial commit'"
    echo "git push -u origin main"
elif [ "$status_code" = "404" ]; then
    echo "❌ PROBLEMA: Repositório não existe no GitHub"
    echo ""
    echo "SOLUÇÃO:"
    echo "1. Acesse: https://github.com/new"
    echo "2. Nome: sap-skills-power"
    echo "3. Visibilidade: Public"
    echo "4. NÃO adicione README, .gitignore ou license"
    echo "5. Clique em 'Create repository'"
    echo "6. Execute novamente: ./upload-simples.sh"
elif [ "$status_code" = "200" ]; then
    echo "⚠️  PROBLEMA: Repositório já existe e pode ter conteúdo"
    echo ""
    echo "SOLUÇÃO 1 (Recomendada - Mesclar):"
    echo "git pull origin main --allow-unrelated-histories"
    echo "git push -u origin main"
    echo ""
    echo "SOLUÇÃO 2 (Forçar - Sobrescreve tudo):"
    echo "git push -u origin main --force"
else
    echo "⚠️  Problema desconhecido"
    echo ""
    echo "Tente executar manualmente:"
    echo "git push -u origin main -v"
fi
echo ""
