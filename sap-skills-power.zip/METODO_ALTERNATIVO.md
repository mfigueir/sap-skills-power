# 🔄 Método Alternativo - GitHub CLI

Se os scripts continuam falhando, use o GitHub CLI (mais confiável).

## 📦 Instalação do GitHub CLI

### macOS
```bash
brew install gh
```

### Linux (Ubuntu/Debian)
```bash
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh
```

### Verificar instalação
```bash
gh --version
```

---

## 🚀 Upload com GitHub CLI

### Passo 1: Autenticar

```bash
gh auth login
```

Escolha:
- What account do you want to log into? **GitHub.com**
- What is your preferred protocol for Git operations? **HTTPS**
- Authenticate Git with your GitHub credentials? **Yes**
- How would you like to authenticate GitHub CLI? **Paste an authentication token**
- Paste your authentication token: **[cole seu token]**

### Passo 2: Preparar Repositório Local

```bash
cd sap-skills

# Limpar
rm -rf .git

# Inicializar
git init
git add .
git commit -m "Initial commit: SAP Skills Power v1.0.0"
git branch -M main
```

### Passo 3: Verificar se Repositório Existe

```bash
gh repo view mfigueir/sap-skills-power
```

**Se existir:**
```bash
# Deletar (se quiser recomeçar)
gh repo delete mfigueir/sap-skills-power --yes

# Ou apenas fazer push forçado (próximo passo)
```

**Se não existir:**
```bash
# Criar repositório
gh repo create sap-skills-power --public --source=. --remote=origin
```

### Passo 4: Push

```bash
# Push normal
git push -u origin main

# Ou push forçado se necessário
git push -u origin main --force
```

---

## 🎯 Script Completo com GitHub CLI

```bash
#!/bin/bash

cd sap-skills

# Autenticar (se ainda não fez)
gh auth login

# Limpar e preparar
rm -rf .git
git init
git add .
git commit -m "Initial commit: SAP Skills Power v1.0.0"
git branch -M main

# Verificar se repo existe e deletar
gh repo view mfigueir/sap-skills-power 2>/dev/null && \
gh repo delete mfigueir/sap-skills-power --yes

# Criar novo repositório
gh repo create sap-skills-power --public --source=. --remote=origin --push

echo "✅ Pronto! Repositório criado e código enviado!"
echo "📍 https://github.com/mfigueir/sap-skills-power"
```

---

## 🔍 Comandos Úteis do GitHub CLI

### Ver repositório
```bash
gh repo view mfigueir/sap-skills-power
```

### Listar seus repositórios
```bash
gh repo list mfigueir
```

### Deletar repositório
```bash
gh repo delete mfigueir/sap-skills-power --yes
```

### Criar repositório
```bash
gh repo create sap-skills-power --public
```

### Abrir repositório no browser
```bash
gh repo view mfigueir/sap-skills-power --web
```

---

## 💡 Vantagens do GitHub CLI

- ✅ Autenticação mais confiável
- ✅ Não precisa lidar com tokens manualmente
- ✅ Comandos mais simples
- ✅ Menos erros de permissão
- ✅ Pode criar/deletar repos facilmente

---

## 🆘 Troubleshooting

### Erro: "gh: command not found"
Instale o GitHub CLI (veja início deste guia)

### Erro: "authentication required"
```bash
gh auth login
```

### Erro: "repository not found"
```bash
# Criar repositório
gh repo create sap-skills-power --public
```

### Erro: "already exists"
```bash
# Deletar e recriar
gh repo delete mfigueir/sap-skills-power --yes
gh repo create sap-skills-power --public --source=. --remote=origin --push
```

---

## ✅ Recomendação Final

Use este método se:
- ❌ Scripts com git push continuam falhando
- ❌ Problemas de autenticação persistem
- ❌ Erros de permissão não resolvidos
- ✅ Quer uma solução mais confiável

---

**Este é o método mais confiável!** 🚀
