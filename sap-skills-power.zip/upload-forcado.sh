#!/bin/bash

# Script para FORÇAR upload - Sobrescreve tudo no GitHub
# Use quando todos os outros métodos falharem

set -e

echo "🚀 SAP Skills Power - Upload FORÇADO"
echo "====================================="
echo ""
echo "⚠️  ATENÇÃO: Este script irá SOBRESCREVER todo o conteúdo no GitHub!"
echo ""
read -p "Tem certeza que deseja continuar? (s/n): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[SsYy]$ ]]; then
    echo "❌ Upload cancelado"
    exit 0
fi

# Verificar se estamos no diretório correto
if [ ! -f "POWER.md" ]; then
    echo "❌ Erro: Execute este script dentro da pasta sap-skills/"
    exit 1
fi

echo ""
echo "📋 Passo 1: Limpando repositório Git anterior..."
rm -rf .git
echo "✅ Limpo"
echo ""

echo "📋 Passo 2: Inicializando novo repositório Git..."
git init
echo "✅ Inicializado"
echo ""

echo "📋 Passo 3: Adicionando todos os arquivos..."
git add .
echo "✅ Arquivos adicionados"
echo ""

echo "📋 Passo 4: Criando commit inicial..."
git commit -m "Initial commit: SAP Skills Power v1.0.0

- 35+ specialized SAP skills
- 4 comprehensive steering guides
- Complete documentation
- GitHub Actions integration
- Issue and PR templates
- GPL v3.0 license"
echo "✅ Commit criado"
echo ""

echo "📋 Passo 5: Renomeando branch para main..."
git branch -M main
echo "✅ Branch main configurada"
echo ""

echo "📋 Passo 6: Adicionando remote do GitHub..."
git remote add origin https://github.com/mfigueir/sap-skills-power.git 2>/dev/null || \
git remote set-url origin https://github.com/mfigueir/sap-skills-power.git
echo "✅ Remote configurado"
echo ""

echo "📋 Passo 7: Fazendo push FORÇADO para GitHub..."
echo "⚠️  Você precisará autenticar com suas credenciais do GitHub"
echo "⚠️  Use seu Personal Access Token como senha"
echo ""

if git push -u origin main --force; then
    echo ""
    echo "✅ ✅ ✅ SUCESSO! ✅ ✅ ✅"
    echo ""
    echo "🎉 Seu SAP Skills Power está no GitHub!"
    echo ""
    echo "📍 URL: https://github.com/mfigueir/sap-skills-power"
    echo ""
    echo "📋 Próximos passos:"
    echo "1. Acesse: https://github.com/mfigueir/sap-skills-power"
    echo "2. Configure Issues e Discussions (Settings)"
    echo "3. Adicione topics: sap, kiro, btp, cap, fiori, ui5, abap, hana"
    echo "4. Crie a primeira release (v1.0.0)"
    echo ""
else
    echo ""
    echo "❌ Erro ao fazer push forçado"
    echo ""
    echo "Possíveis causas:"
    echo "1. Token sem permissão 'repo'"
    echo "2. Branch protegida no GitHub"
    echo "3. Problema de conectividade"
    echo ""
    echo "Soluções:"
    echo ""
    echo "A) Verificar permissões do token:"
    echo "   - Acesse: https://github.com/settings/tokens"
    echo "   - Gere novo token com permissão 'repo'"
    echo ""
    echo "B) Desabilitar proteção de branch:"
    echo "   - Acesse: https://github.com/mfigueir/sap-skills-power/settings/branches"
    echo "   - Remova regras de proteção da branch 'main'"
    echo ""
    echo "C) Verificar conectividade:"
    echo "   git ls-remote origin"
    echo ""
    exit 1
fi
