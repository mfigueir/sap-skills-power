#!/bin/bash

# Script Simplificado para Upload do SAP Skills Power
# Soluciona o erro: "src refspec main does not match any"

set -e

echo "🚀 SAP Skills Power - Upload Simplificado"
echo "=========================================="
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "POWER.md" ]; then
    echo "❌ Erro: Execute este script dentro da pasta sap-skills/"
    exit 1
fi

echo "📋 Passo 1: Limpando repositório Git anterior..."
rm -rf .git
echo "✅ Limpo"
echo ""

echo "📋 Passo 2: Inicializando novo repositório Git..."
git init
echo "✅ Inicializado"
echo ""

echo "📋 Passo 3: Adicionando todos os arquivos..."
git add .
echo "✅ Arquivos adicionados"
echo ""

echo "📋 Passo 4: Criando commit inicial..."
git commit -m "Initial commit: SAP Skills Power v1.0.0

- 35+ specialized SAP skills
- 4 comprehensive steering guides  
- Complete documentation
- GitHub Actions integration
- Issue and PR templates
- GPL v3.0 license"
echo "✅ Commit criado"
echo ""

echo "📋 Passo 5: Renomeando branch para main..."
git branch -M main
echo "✅ Branch main configurada"
echo ""

echo "📋 Passo 6: Adicionando remote do GitHub..."
git remote add origin https://github.com/mfigueir/sap-skills-power.git 2>/dev/null || \
git remote set-url origin https://github.com/mfigueir/sap-skills-power.git
echo "✅ Remote configurado"
echo ""

echo "📋 Passo 7: Fazendo push para GitHub..."
echo "⚠️  Você precisará autenticar com suas credenciais do GitHub"
echo ""

if git push -u origin main; then
    echo ""
    echo "✅ ✅ ✅ SUCESSO! ✅ ✅ ✅"
    echo ""
    echo "🎉 Seu SAP Skills Power está no GitHub!"
    echo ""
    echo "📍 URL: https://github.com/mfigueir/sap-skills-power"
    echo ""
    echo "📋 Próximos passos:"
    echo "1. Acesse o repositório"
    echo "2. Configure Issues e Discussions"
    echo "3. Adicione topics: sap, kiro, btp, cap, fiori"
    echo "4. Crie a primeira release (v1.0.0)"
    echo ""
else
    echo ""
    echo "❌ Erro ao fazer push"
    echo ""
    echo "Possíveis soluções:"
    echo "1. Verifique se criou o repositório: https://github.com/new"
    echo "2. Nome deve ser: sap-skills-power"
    echo "3. Use Personal Access Token como senha"
    echo "   Gere em: https://github.com/settings/tokens"
    echo ""
    exit 1
fi
