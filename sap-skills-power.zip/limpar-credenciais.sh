#!/bin/bash

echo "🔧 Limpando Credenciais do GitHub"
echo "=================================="
echo ""

echo "📋 Removendo credenciais antigas do macOS Keychain..."
echo ""

# Criar arquivo temporário com as informações
cat <<EOF | git credential-osxkeychain erase
protocol=https
host=github.com
EOF

echo "✅ Credenciais removidas!"
echo ""
echo "📋 Agora tente o push novamente:"
echo ""
echo "   git push -u origin main"
echo ""
echo "Desta vez ele DEVE pedir username e password."
echo ""
echo "Use:"
echo "  Username: mfigueir"
echo "  Password: [seu Personal Access Token]"
echo ""
