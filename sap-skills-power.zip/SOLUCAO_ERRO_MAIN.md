# 🔧 Solução: "src refspec main does not match any"

## ❌ Erro

```
error: src refspec main does not match any
error: failed to push some refs to 'https://github.com/mfigueir/sap-skills-power.git'
```

## ✅ Solução Rápida

Execute estes comandos na pasta `sap-skills`:

```bash
# 1. Verificar status
git status

# 2. Adicionar todos os arquivos
git add .

# 3. Criar commit
git commit -m "Initial commit: SAP Skills Power v1.0.0"

# 4. Verificar branch
git branch

# 5. Se não houver branch, criar main
git checkout -b main

# 6. Configurar remote (se ainda não configurou)
git remote add origin https://github.com/mfigueir/sap-skills-power.git

# 7. Fazer push
git push -u origin main
```

## 📋 Passo a Passo Detalhado

### Passo 1: Limpar e Recomeçar

```bash
cd sap-skills

# Remover .git se existir
rm -rf .git

# Inicializar novamente
git init
```

### Passo 2: Adicionar Arquivos

```bash
# Adicionar todos os arquivos
git add .

# Verificar o que foi adicionado
git status
```

Você deve ver algo como:
```
On branch master
Changes to be committed:
  new file:   README.md
  new file:   POWER.md
  ...
```

### Passo 3: Criar Commit

```bash
git commit -m "Initial commit: SAP Skills Power v1.0.0"
```

Você deve ver:
```
[master (root-commit) abc1234] Initial commit: SAP Skills Power v1.0.0
 XX files changed, XXXX insertions(+)
 create mode 100644 README.md
 ...
```

### Passo 4: Renomear Branch para Main

```bash
git branch -M main
```

### Passo 5: Adicionar Remote

```bash
# Verificar se remote já existe
git remote -v

# Se não existir, adicionar
git remote add origin https://github.com/mfigueir/sap-skills-power.git

# Se já existir, atualizar URL
git remote set-url origin https://github.com/mfigueir/sap-skills-power.git
```

### Passo 6: Push para GitHub

```bash
git push -u origin main
```

## 🎯 Script Completo (Copie e Cole)

```bash
#!/bin/bash

# Navegue até a pasta sap-skills
cd sap-skills

# Limpar repositório Git anterior (se houver)
rm -rf .git

# Inicializar Git
git init

# Adicionar todos os arquivos
git add .

# Criar commit
git commit -m "Initial commit: SAP Skills Power v1.0.0"

# Renomear branch para main
git branch -M main

# Adicionar remote
git remote add origin https://github.com/mfigueir/sap-skills-power.git

# Push para GitHub
git push -u origin main
```

## 🔍 Verificações

### Verificar se há arquivos para commitar

```bash
git status
```

Deve mostrar arquivos em verde (staged) ou vermelho (not staged).

### Verificar se há commits

```bash
git log
```

Deve mostrar pelo menos um commit.

### Verificar branch atual

```bash
git branch
```

Deve mostrar `* main` (com asterisco).

### Verificar remote

```bash
git remote -v
```

Deve mostrar:
```
origin  https://github.com/mfigueir/sap-skills-power.git (fetch)
origin  https://github.com/mfigueir/sap-skills-power.git (push)
```

## 🆘 Ainda com Problemas?

### Problema: "nothing to commit"

```bash
# Forçar adição de arquivos
git add -A
git commit -m "Initial commit"
```

### Problema: "remote origin already exists"

```bash
# Remover remote existente
git remote remove origin

# Adicionar novamente
git remote add origin https://github.com/mfigueir/sap-skills-power.git
```

### Problema: "repository not found"

1. Verifique se criou o repositório no GitHub: https://github.com/new
2. Nome deve ser exatamente: `sap-skills-power`
3. Deve estar na conta: `mfigueir`

### Problema: Autenticação falhou

Use Personal Access Token:
1. Acesse: https://github.com/settings/tokens
2. Generate new token (classic)
3. Marque: `repo`
4. Copie o token
5. Use como senha quando o Git solicitar

## ✅ Teste Final

Após executar os comandos, verifique:

```bash
# 1. Verificar se está na branch main
git branch
# Deve mostrar: * main

# 2. Verificar se há commits
git log --oneline
# Deve mostrar: abc1234 Initial commit: SAP Skills Power v1.0.0

# 3. Verificar remote
git remote -v
# Deve mostrar a URL do GitHub

# 4. Tentar push
git push -u origin main
```

## 🎉 Sucesso!

Se tudo funcionou, você verá:

```
Enumerating objects: XX, done.
Counting objects: 100% (XX/XX), done.
Delta compression using up to X threads
Compressing objects: 100% (XX/XX), done.
Writing objects: 100% (XX/XX), XX.XX KiB | XX.XX MiB/s, done.
Total XX (delta X), reused 0 (delta 0), pack-reused 0
To https://github.com/mfigueir/sap-skills-power.git
 * [new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
```

Seu repositório está no ar: **https://github.com/mfigueir/sap-skills-power** 🎉

---

**Precisa de mais ajuda?** Abra uma issue ou consulte a documentação do Git.
