# 🔧 Solução: "failed to push some refs"

## ❌ Erro Completo

```
error: failed to push some refs to 'https://github.com/mfigueir/sap-skills-power.git'
```

## 🔍 Diagnóstico Primeiro

Execute o script de diagnóstico:

```bash
cd sap-skills
./diagnostico.sh
```

Isso identificará o problema exato.

---

## ✅ Soluções por Causa

### Causa 1: Repositório Não Existe no GitHub

**Sintoma:** Erro 404 ou "repository not found"

**Solução:**

1. Acesse: https://github.com/new
2. Preencha:
   - Nome: `sap-skills-power`
   - Visibilidade: Public
   - **NÃO** marque nenhuma opção (README, .gitignore, license)
3. Clique em "Create repository"
4. Execute novamente:
   ```bash
   ./upload-simples.sh
   ```

---

### Causa 2: Repositório Já Existe com Conteúdo

**Sintoma:** "Updates were rejected" ou "non-fast-forward"

**Solução A - Mesclar (Recomendada):**

```bash
cd sap-skills

# Fazer pull primeiro
git pull origin main --allow-unrelated-histories

# Resolver conflitos se houver
# Depois fazer push
git push -u origin main
```

**Solução B - Forçar (Sobrescreve tudo no GitHub):**

```bash
cd sap-skills

# ATENÇÃO: Isso apaga tudo que está no GitHub!
git push -u origin main --force
```

---

### Causa 3: Problemas de Autenticação

**Sintoma:** "Authentication failed" ou "Permission denied"

**Solução:**

1. Verifique se o token tem permissão `repo`
2. Gere um novo token: https://github.com/settings/tokens
3. Marque: ✅ `repo` (Full control of private repositories)
4. Copie o token
5. Tente novamente e use o token como senha

**Configurar credenciais (opcional):**

```bash
# macOS
git config --global credential.helper osxkeychain

# Linux
git config --global credential.helper cache --timeout=3600

# Limpar credenciais antigas
git credential-osxkeychain erase
# Digite: host=github.com
# Digite: protocol=https
# Pressione Enter duas vezes
```

---

### Causa 4: Branch Protegida

**Sintoma:** "protected branch hook declined"

**Solução:**

1. Acesse: https://github.com/mfigueir/sap-skills-power/settings/branches
2. Verifique se há regras de proteção na branch `main`
3. Desabilite temporariamente ou ajuste as regras
4. Tente o push novamente

---

### Causa 5: Arquivo Muito Grande

**Sintoma:** "file exceeds GitHub's file size limit"

**Solução:**

```bash
# Verificar arquivos grandes
find . -type f -size +50M

# Adicionar ao .gitignore
echo "arquivo-grande.zip" >> .gitignore

# Remover do staging
git rm --cached arquivo-grande.zip

# Commit e push
git commit -m "Remove large file"
git push -u origin main
```

---

## 🚀 Solução Rápida Universal

Se nada funcionar, tente esta sequência:

```bash
cd sap-skills

# 1. Limpar tudo
rm -rf .git

# 2. Inicializar
git init

# 3. Adicionar arquivos
git add .

# 4. Commit
git commit -m "Initial commit: SAP Skills Power v1.0.0"

# 5. Renomear branch
git branch -M main

# 6. Adicionar remote
git remote add origin https://github.com/mfigueir/sap-skills-power.git

# 7. Verificar se repositório existe no GitHub
# Se NÃO existir, crie em: https://github.com/new

# 8. Push (forçado se necessário)
git push -u origin main --force
```

---

## 🔍 Comandos de Diagnóstico

### Verificar status do Git

```bash
git status
```

### Verificar commits

```bash
git log --oneline
```

### Verificar remote

```bash
git remote -v
```

### Verificar branch

```bash
git branch -a
```

### Testar conectividade

```bash
git ls-remote origin
```

### Push com verbose (ver detalhes do erro)

```bash
git push -u origin main -v
```

---

## 📋 Checklist de Verificação

Antes de fazer push, verifique:

- [ ] Repositório criado no GitHub
- [ ] Nome correto: `sap-skills-power`
- [ ] Conta correta: `mfigueir`
- [ ] Token com permissão `repo`
- [ ] Pelo menos 1 commit local
- [ ] Branch `main` existe
- [ ] Remote configurado corretamente
- [ ] Sem arquivos muito grandes (>100MB)

---

## 🆘 Ainda com Problemas?

### Opção 1: Push Manual com Detalhes

```bash
cd sap-skills
GIT_CURL_VERBOSE=1 git push -u origin main -v
```

Isso mostrará detalhes completos do erro.

### Opção 2: Usar GitHub CLI

```bash
# Instalar
brew install gh

# Autenticar
gh auth login

# Criar repositório
gh repo create sap-skills-power --public --source=. --remote=origin

# Push
git push -u origin main
```

### Opção 3: Verificar Logs

```bash
# Ver logs do Git
git log --all --decorate --oneline --graph

# Ver configuração
git config --list
```

---

## 💡 Dicas

### Evitar Problemas Futuros

1. **Sempre crie o repositório vazio no GitHub primeiro**
2. **Não adicione README, .gitignore ou license ao criar**
3. **Use tokens com permissões corretas**
4. **Verifique se não há arquivos grandes**

### Boas Práticas

```bash
# Sempre verificar antes de push
git status
git log --oneline
git remote -v

# Fazer push com verbose para ver detalhes
git push -u origin main -v
```

---

## 📞 Precisa de Mais Ajuda?

1. Execute: `./diagnostico.sh`
2. Copie a saída completa
3. Verifique qual é o problema específico
4. Siga a solução correspondente acima

---

**Boa sorte!** 🚀
