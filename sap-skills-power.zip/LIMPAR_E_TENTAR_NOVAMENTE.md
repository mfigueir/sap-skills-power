# 🔧 Limpar Credenciais e Tentar Novamente

## 🔍 Problema Identificado

O Git está usando **credenciais antigas** armazenadas no macOS Keychain. Por isso não pede username/password e o push falha.

---

## ✅ Solução (2 Comandos)

### Passo 1: Limpar Credenciais Antigas

Execute no terminal:

```bash
cd sap-skills
./limpar-credenciais.sh
```

Ou manualmente:

```bash
cd sap-skills
printf "protocol=https\nhost=github.com\n" | git credential-osxkeychain erase
```

### Passo 2: Fazer Push Novamente

```bash
git push -u origin main
```

**AGORA** ele deve pedir:
- **Username:** `mfigueir`
- **Password:** [Cole seu Personal Access Token]

---

## 🔑 Se Não Tiver Token Válido

1. Acesse: https://github.com/settings/tokens
2. Clique em **"Generate new token (classic)"**
3. Preencha:
   - **Note:** `SAP Skills Power`
   - **Expiration:** 90 days
   - **Scopes:** Marque ✅ **repo**
4. Clique em **"Generate token"**
5. **COPIE O TOKEN** (você só verá uma vez!)
6. Use como password no push

---

## 📋 Passo a Passo Completo

### 1. Limpar Credenciais

```bash
cd sap-skills
./limpar-credenciais.sh
```

Você verá:
```
🔧 Limpando Credenciais do GitHub
==================================

📋 Removendo credenciais antigas do macOS Keychain...

✅ Credenciais removidas!
```

### 2. Fazer Push

```bash
git push -u origin main
```

### 3. Autenticar

Quando aparecer:
```
Username for 'https://github.com': 
```
Digite: **mfigueir** e pressione Enter

Quando aparecer:
```
Password for 'https://mfigueir@github.com':
```
Cole seu **Personal Access Token** e pressione Enter

⚠️ A senha não aparecerá na tela - isso é normal!

### 4. Sucesso! 🎉

Você verá:
```
Enumerating objects: 25, done.
Counting objects: 100% (25/25), done.
Delta compression using up to 8 threads
Compressing objects: 100% (23/23), done.
Writing objects: 100% (25/25), 45.67 KiB | 7.61 MiB/s, done.
Total 25 (delta 2), reused 0 (delta 0), pack-reused 0
To https://github.com/mfigueir/sap-skills-power.git
 * [new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
```

---

## 🆘 Alternativa: Desabilitar Credential Helper Temporariamente

Se o script não funcionar, tente:

```bash
cd sap-skills

# Desabilitar credential helper temporariamente
git config --unset credential.helper

# Fazer push (agora vai pedir credenciais)
git push -u origin main

# Reabilitar credential helper
git config --global credential.helper osxkeychain
```

---

## 🔍 Verificar se Credenciais Foram Limpas

```bash
# Tentar acessar o repositório
git ls-remote origin

# Se pedir credenciais = ✅ Limpou com sucesso
# Se não pedir = ❌ Ainda tem credenciais antigas
```

---

## 💡 Alternativa: Usar Token na URL (Temporário)

Se nada funcionar, use o token diretamente na URL:

```bash
cd sap-skills

# Adicionar token na URL (substitua SEU_TOKEN)
git remote set-url origin https://SEU_TOKEN@github.com/mfigueir/sap-skills-power.git

# Push
git push -u origin main

# IMPORTANTE: Remover token da URL depois
git remote set-url origin https://github.com/mfigueir/sap-skills-power.git
```

⚠️ **Cuidado:** Não commite com o token na URL!

---

## 🎯 Resumo

1. **Limpar credenciais:** `./limpar-credenciais.sh`
2. **Fazer push:** `git push -u origin main`
3. **Autenticar:** Use seu token como password

---

## ✅ Após o Sucesso

Verifique no navegador:
```
https://github.com/mfigueir/sap-skills-power
```

Configure o repositório:
1. Habilite Issues e Discussions
2. Adicione topics: sap, kiro, btp, cap, fiori
3. Crie a primeira release (v1.0.0)

---

**Agora vai funcionar!** 🚀
