#!/bin/bash

# Script para fazer upload do SAP Skills Power para GitHub
# Autor: mfigueir
# Repositório: https://github.com/mfigueir/sap-skills-power

set -e  # Parar em caso de erro

echo "🚀 SAP Skills Power - Upload para GitHub"
echo "=========================================="
echo ""

# Cores para output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Verificar se estamos no diretório correto
if [ ! -f "POWER.md" ]; then
    echo -e "${RED}❌ Erro: POWER.md não encontrado!${NC}"
    echo "Execute este script dentro da pasta sap-skills/"
    exit 1
fi

echo -e "${BLUE}📋 Verificando arquivos necessários...${NC}"

# Lista de arquivos necessários
required_files=(
    "README.md"
    "POWER.md"
    "LICENSE"
    "CONTRIBUTING.md"
    "CHANGELOG.md"
    "SETUP.md"
    "QUICK_REFERENCE.md"
    "GITHUB_UPLOAD_GUIDE.md"
    ".gitignore"
    ".markdownlint.json"
)

missing_files=0
for file in "${required_files[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✅ $file${NC}"
    else
        echo -e "${RED}❌ $file (faltando)${NC}"
        missing_files=$((missing_files + 1))
    fi
done

if [ $missing_files -gt 0 ]; then
    echo -e "${RED}❌ Erro: $missing_files arquivo(s) faltando!${NC}"
    exit 1
fi

echo ""
echo -e "${BLUE}📁 Verificando diretórios...${NC}"

# Verificar diretórios
if [ -d "steering" ]; then
    echo -e "${GREEN}✅ steering/${NC}"
else
    echo -e "${RED}❌ steering/ (faltando)${NC}"
    exit 1
fi

if [ -d ".github" ]; then
    echo -e "${GREEN}✅ .github/${NC}"
else
    echo -e "${RED}❌ .github/ (faltando)${NC}"
    exit 1
fi

echo ""
echo -e "${YELLOW}⚠️  Antes de continuar, certifique-se de que:${NC}"
echo "1. Você criou o repositório no GitHub: https://github.com/mfigueir/sap-skills-power"
echo "2. Você tem permissões de escrita no repositório"
echo "3. Você revisou todos os arquivos"
echo ""
read -p "Deseja continuar? (s/n): " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[SsYy]$ ]]; then
    echo -e "${YELLOW}⚠️  Upload cancelado pelo usuário${NC}"
    exit 0
fi

echo ""
echo -e "${BLUE}🔧 Inicializando repositório Git...${NC}"

# Verificar se já é um repositório git
if [ -d ".git" ]; then
    echo -e "${YELLOW}⚠️  Repositório Git já existe. Pulando inicialização...${NC}"
else
    git init
    echo -e "${GREEN}✅ Repositório Git inicializado${NC}"
fi

echo ""
echo -e "${BLUE}📦 Adicionando arquivos ao Git...${NC}"
git add .
echo -e "${GREEN}✅ Arquivos adicionados${NC}"

echo ""
echo -e "${BLUE}💾 Criando commit inicial...${NC}"

# Verificar se há algo para commitar
if git diff-index --quiet HEAD -- 2>/dev/null; then
    echo -e "${YELLOW}⚠️  Nada para commitar (já existe commit)${NC}"
else
    git commit -m "Initial commit: SAP Skills Power v1.0.0

- 35+ specialized SAP skills
- 4 comprehensive steering guides
- Complete documentation
- GitHub Actions integration
- Issue and PR templates
- GPL v3.0 license" || {
        echo -e "${YELLOW}⚠️  Tentando criar commit...${NC}"
        git commit -m "Initial commit: SAP Skills Power v1.0.0" || echo -e "${RED}❌ Erro ao criar commit${NC}"
    }
fi

# Verificar se existe pelo menos um commit
if ! git rev-parse HEAD >/dev/null 2>&1; then
    echo -e "${RED}❌ Erro: Nenhum commit encontrado!${NC}"
    echo "Criando commit forçado..."
    git commit --allow-empty -m "Initial commit: SAP Skills Power v1.0.0"
fi

echo ""
echo -e "${BLUE}🔗 Configurando remote do GitHub...${NC}"

# Verificar se remote já existe
if git remote | grep -q "origin"; then
    echo -e "${YELLOW}⚠️  Remote 'origin' já existe. Atualizando URL...${NC}"
    git remote set-url origin https://github.com/mfigueir/sap-skills-power.git
else
    git remote add origin https://github.com/mfigueir/sap-skills-power.git
fi

echo -e "${GREEN}✅ Remote configurado: https://github.com/mfigueir/sap-skills-power.git${NC}"

echo ""
echo -e "${BLUE}🌿 Configurando branch principal...${NC}"

# Verificar se a branch atual existe
current_branch=$(git branch --show-current 2>/dev/null || echo "")

if [ -z "$current_branch" ]; then
    echo -e "${YELLOW}⚠️  Nenhuma branch ativa. Criando branch main...${NC}"
    git checkout -b main
else
    echo -e "${BLUE}Branch atual: $current_branch${NC}"
    if [ "$current_branch" != "main" ]; then
        git branch -M main
    fi
fi

echo -e "${GREEN}✅ Branch 'main' configurada${NC}"

echo ""
echo -e "${BLUE}🚀 Fazendo push para GitHub...${NC}"
echo -e "${YELLOW}⚠️  Você pode precisar autenticar com suas credenciais do GitHub${NC}"
echo ""

if git push -u origin main; then
    echo ""
    echo -e "${GREEN}✅ Upload concluído com sucesso!${NC}"
    echo ""
    echo "🎉 Seu SAP Skills Power está agora no GitHub!"
    echo ""
    echo "📍 URL do repositório:"
    echo "   https://github.com/mfigueir/sap-skills-power"
    echo ""
    echo "📋 Próximos passos:"
    echo "1. Acesse: https://github.com/mfigueir/sap-skills-power"
    echo "2. Configure o repositório (Settings):"
    echo "   - Habilite Issues e Discussions"
    echo "   - Adicione topics: sap, kiro, btp, cap, fiori, ui5, abap, hana"
    echo "   - Configure a descrição"
    echo "3. Crie a primeira release (v1.0.0)"
    echo "4. Compartilhe com a comunidade!"
    echo ""
else
    echo ""
    echo -e "${RED}❌ Erro ao fazer push para GitHub${NC}"
    echo ""
    echo "Possíveis soluções:"
    echo "1. Verifique se o repositório existe: https://github.com/mfigueir/sap-skills-power"
    echo "2. Verifique suas credenciais do GitHub"
    echo "3. Tente fazer push manualmente:"
    echo "   git push -u origin main"
    echo ""
    exit 1
fi
